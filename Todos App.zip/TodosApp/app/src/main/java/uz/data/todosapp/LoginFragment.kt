package uz.data.todosapp

import androidx.fragment.app.Fragment

class LoginFragment: Fragment(R.layout.fragment_login) {
}